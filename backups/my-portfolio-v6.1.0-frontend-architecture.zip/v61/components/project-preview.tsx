"use client";

import { Code2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { ProjectItem } from "./portfolio-data";

export function ProjectPreview({ project }: { project: ProjectItem }) {
    const viewportRef = useRef<HTMLDivElement | null>(null);
    const imageRef = useRef<HTMLImageElement | null>(null);
    const [isScrollable, setIsScrollable] = useState(false);

    useEffect(() => {
        const updateScrollable = () => {
            const viewport = viewportRef.current;
            const image = imageRef.current;
            if (!viewport || !image) return;
            setIsScrollable(viewport.scrollHeight > viewport.clientHeight + 4 || viewport.scrollWidth > viewport.clientWidth + 4);
        };

        updateScrollable();
        const image = imageRef.current;
        const resizeObserver = typeof ResizeObserver !== "undefined" && image ? new ResizeObserver(updateScrollable) : null;
        if (image) resizeObserver?.observe(image);
        window.addEventListener("resize", updateScrollable, { passive: true });
        return () => {
            resizeObserver?.disconnect();
            window.removeEventListener("resize", updateScrollable);
        };
    }, [project.imageUrl]);

    return (
        <div ref={viewportRef} className="project-preview-scroll absolute inset-x-0 bottom-0 top-9 overflow-auto overscroll-contain bg-slate-900" aria-label={`${project.title} preview. Scroll to explore the full image when needed.`}>
            {project.imageUrl ? (
                <img ref={imageRef} src={project.imageUrl} alt={`${project.title} project preview`} onLoad={() => {
                    const viewport = viewportRef.current;
                    const image = imageRef.current;
                    if (viewport && image) setIsScrollable(viewport.scrollHeight > viewport.clientHeight + 4 || viewport.scrollWidth > viewport.clientWidth + 4);
                }} className="block h-auto min-h-full w-full max-w-none object-contain object-top align-top transition duration-500 group-hover:brightness-105" />
            ) : (
                <div className="flex min-h-full items-center justify-center bg-gradient-to-br from-sky-500/20 via-slate-900 to-slate-950"><Code2 className="h-16 w-16 text-sky-400/60" /></div>
            )}
            {isScrollable && <>
                <div className="pointer-events-none sticky bottom-0 left-0 right-0 flex justify-center pb-3"><span className="rounded-full border border-white/15 bg-black/55 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.16em] text-white shadow-lg backdrop-blur-xl">Scroll to explore</span></div>
                <div className="pointer-events-none sticky bottom-0 left-0 right-0 -mt-14 h-14 bg-gradient-to-t from-slate-950/80 to-transparent" />
            </>}
        </div>
    );
}
