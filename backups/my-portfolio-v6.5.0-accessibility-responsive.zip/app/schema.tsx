const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ||
  "http://localhost:3000";

export function PersonSchema() {
  const sameAs = [
    process.env.NEXT_PUBLIC_GITHUB_URL,
    process.env.NEXT_PUBLIC_LINKEDIN_URL,
  ].filter(Boolean);

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Frunco Ruiz",
          jobTitle: "Full-Stack Developer & AI Product Builder",
          url: siteUrl,
          ...(sameAs.length ? { sameAs } : {}),
        }),
      }}
    />
  );
}
