import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { PersonSchema } from "./schema";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ||
  "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Frunco Ruiz | Full-Stack Developer & AI Product Builder",
    template: "%s | Frunco Ruiz",
  },
  description:
    "Frunco Ruiz builds AI-powered web applications, SaaS platforms, and modern full-stack digital products.",
  applicationName: "Frunco Ruiz Portfolio",
  authors: [{ name: "Frunco Ruiz" }],
  creator: "Frunco Ruiz",
  publisher: "Frunco Ruiz",
  alternates: {
    canonical: siteUrl,
  },
  openGraph: {
    type: "website",
    url: siteUrl,
    siteName: "Frunco Ruiz Portfolio",
    title: "Frunco Ruiz | Full-Stack Developer & AI Product Builder",
    description:
      "Full-stack development, AI integration, product engineering, and polished digital experiences.",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "Frunco Ruiz | Full-Stack Developer & AI Product Builder",
    description:
      "Full-stack development, AI integration, product engineering, and polished digital experiences.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  colorScheme: "light dark",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f8fafc" },
    { media: "(prefers-color-scheme: dark)", color: "#050911" },
  ],
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <PersonSchema />
        {children}
      </body>
    </html>
  );
}
